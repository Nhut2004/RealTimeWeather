package com.example.weather.api

data class Condition(
    val code: Int,
    val icon: String,
    val text: String
)