package com.example.weather.api

object Constant {

    val apiKey = "3f9d4069b0da460c90c81938252203"

}